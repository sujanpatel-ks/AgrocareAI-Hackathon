
import { StoreLocation } from "../types";

export const LOCAL_STORES: StoreLocation[] = [
  {
    title: "Regional Agri-Center Alpha",
    uri: "https://maps.google.com/?q=Agri-Center+Alpha",
    lat: 18.5204, // Mock coordinates near Pune, India context
    lng: 73.8567,
    isVerified: true,
    phone: "+91-20-2445-1234",
    inventory: ["Fungicides", "Rice Treatment", "Organic Compost", "Blast-Control"]
  },
  {
    title: "Farmer's Friend Depot",
    uri: "https://maps.google.com/?q=Farmers+Friend+Depot",
    lat: 18.5300,
    lng: 73.8400,
    isVerified: true,
    phone: "+91-20-2445-5678",
    inventory: ["Pesticides", "Spray Equipment", "Seed Treatment"]
  },
  {
    title: "Village Supply Co.",
    uri: "https://maps.google.com/?q=Village+Supply+Co",
    lat: 18.5100,
    lng: 73.8700,
    isVerified: false,
    inventory: ["General Supplies", "Fertilizer"]
  }
];
