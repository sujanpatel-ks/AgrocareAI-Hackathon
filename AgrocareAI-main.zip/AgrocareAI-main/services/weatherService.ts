
import { WeatherForecast, ForecastDay } from "../types";

/**
 * Fetches real-time weather and a 5-day forecast using Open-Meteo (No key required).
 */
export const fetchWeatherForecast = async (lat: number, lng: number): Promise<WeatherForecast> => {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current_weather=true&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weathercode&timezone=auto`;

  const response = await fetch(url);
  if (!response.ok) throw new Error("Weather service unavailable");
  
  const data = await response.json();

  const weatherCodes: Record<number, string> = {
    0: 'Clear', 1: 'Mainly Clear', 2: 'Partly Cloudy', 3: 'Overcast',
    45: 'Fog', 48: 'Depositing Rime Fog',
    51: 'Light Drizzle', 53: 'Moderate Drizzle', 55: 'Dense Drizzle',
    61: 'Slight Rain', 63: 'Moderate Rain', 65: 'Heavy Rain',
    71: 'Slight Snow', 73: 'Moderate Snow', 75: 'Heavy Snow',
    80: 'Rain Showers', 81: 'Violent Rain Showers',
    95: 'Thunderstorm', 96: 'TS with Hail'
  };

  const days: ForecastDay[] = data.daily.time.map((time: string, i: number) => ({
    date: new Date(time).toLocaleDateString('en-US', { weekday: 'short' }),
    tempMax: Math.round(data.daily.temperature_2m_max[i]),
    tempMin: Math.round(data.daily.temperature_2m_min[i]),
    condition: weatherCodes[data.daily.weathercode[i]] || 'Cloudy',
    precipProbability: data.daily.precipitation_probability_max[i]
  })).slice(0, 5);

  return {
    current: {
      temp: Math.round(data.current_weather.temperature),
      humidity: 65, // Humidity isn't in simple current_weather, using mock for sensor feel
      soilMoisture: 32, // Mocked sensor data
      condition: weatherCodes[data.current_weather.weathercode] || 'Optimal'
    },
    days
  };
};
