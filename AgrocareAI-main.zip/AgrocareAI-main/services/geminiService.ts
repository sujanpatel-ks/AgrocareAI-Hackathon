
import { GoogleGenAI, Type, Chat, Modality } from "@google/genai";
import { DiagnosticResult, StoreLocation, WeatherForecast } from "../types";
import { runOfflineDiagnostic } from "./localPathologyEngine";

/**
 * High-precision diagnostic engine using Gemini 3 Pro.
 */
export const analyzeCropHealth = async (imageBase64: string, weatherContext?: string): Promise<DiagnosticResult> => {
  if (!navigator.onLine) {
    return await runOfflineDiagnostic(imageBase64);
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = 'gemini-3-pro-preview';
  
  let mimeType = 'image/jpeg';
  let data = imageBase64;

  if (imageBase64.startsWith('data:')) {
    const match = imageBase64.match(/^data:([^;]+);base64,(.+)$/);
    if (match) {
      mimeType = match[1];
      data = match[2];
    }
  }

  const prompt = `Act as a Senior Plant Pathologist.
  CONTEXT: ${weatherContext || 'Field conditions normal.'}
  
  TASK:
  1. Conduct a molecular-level visual inspection of this crop leaf.
  2. Identify the primary disease or pest infestation.
  3. Provide exact visual evidence coordinates (0-100 scale).
  4. Determine severity and treatment urgency.
  
  Return JSON: { diseaseName, confidence, description, recommendations, urgency, severity, visualEvidence: [{x, y, width, height}] }`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: { parts: [{ inlineData: { mimeType, data } }, { text: prompt }] },
      config: {
        thinkingConfig: { thinkingBudget: 4000 },
        responseMimeType: "application/json",
      }
    });

    return JSON.parse(response.text || '{}') as DiagnosticResult;
  } catch (error) {
    console.error("Cloud inference failed, attempting local fallback...", error);
    return await runOfflineDiagnostic(imageBase64);
  }
};

/**
 * Live Grounding Service using Gemini 2.5 Flash + Google Maps Tool.
 * Finds physical stores that stock specific agricultural treatments.
 * Strictly limited to 25km vicinity for high-accuracy results.
 */
export const findNearbySuppliers = async (
  treatment: string, 
  lat: number, 
  lng: number
): Promise<StoreLocation[]> => {
  if (!navigator.onLine) return [];
  
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  // Explicitly prompt for strict 25km radius to prioritize relevant businesses
  const prompt = `Find specific agricultural supply stores or pesticide dealers STRICTLY within a 25km radius of coordinates ${lat}, ${lng} that likely stock "${treatment}". Focus on verified local businesses.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: { latLng: { latitude: lat, longitude: lng } }
        }
      },
    });

    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    // Map grounding chunks to StoreLocation interface
    const stores: StoreLocation[] = chunks
      .filter((c: any) => c.maps)
      .map((c: any) => ({
        title: c.maps.title,
        uri: c.maps.uri,
        lat: c.maps.placeAnswerSources?.latLng?.latitude,
        lng: c.maps.placeAnswerSources?.latLng?.longitude,
        isVerified: true,
        address: c.maps.title,
        reviewSnippet: c.maps.placeAnswerSources?.reviewSnippets?.[0],
        inventory: [treatment, "General Pesticides", "Fertilizers"] // Heuristic matching based on store type
      }));

    return stores;
  } catch (error) {
    console.error("Grounding service failed:", error);
    return [];
  }
};

export const getWeatherImpactAdvice = async (disease: string, forecast: WeatherForecast): Promise<string> => {
  if (!navigator.onLine) return "Weather analysis requires active data sync.";
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Given a 5-day forecast (${forecast.current.temp}°C, humidity ${forecast.current.humidity}%), explain how this will impact "${disease}". 2 sentences.`;
  const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
  return response.text || "Weather-pathology correlation integrated.";
};

export const createAgroChat = (): Chat => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  return ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: `You are AgroCare Intelligence. Provide expert, safe, and specific agricultural treatment advice.`,
    },
  });
};
