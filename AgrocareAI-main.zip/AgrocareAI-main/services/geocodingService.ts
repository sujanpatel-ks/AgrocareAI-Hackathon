
import { GoogleGenAI, Type } from "@google/genai";

export interface LatLng {
  lat: number;
  lng: number;
}

/**
 * Geocodes a place name or address using Gemini 3 Flash.
 * Returns precise coordinates for map placement by grounding the search in a specific vicinity.
 */
export const geocodePlace = async (placeName: string, vicinity: string): Promise<LatLng | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Act as a high-precision geocoding engine. 
  Find the most accurate latitude and longitude coordinates for the following business:
  Name: "${placeName}"
  Regional Context: "${vicinity}"

  If the exact location is unknown, try to find the central coordinate of the business district or area mentioned.
  Return only a JSON object with 'lat' and 'lng' as numbers. Do not include markdown formatting.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            lat: { type: Type.NUMBER, description: "The latitude coordinate." },
            lng: { type: Type.NUMBER, description: "The longitude coordinate." }
          },
          required: ["lat", "lng"]
        }
      }
    });

    const textResponse = response.text.trim();
    // Safety check for JSON parsing
    const cleanJson = textResponse.replace(/^```json\n?|\n?```$/g, '');
    const data = JSON.parse(cleanJson);
    
    if (typeof data.lat === 'number' && typeof data.lng === 'number') {
      return data as LatLng;
    }
    return null;
  } catch (error) {
    console.warn("Geocoding service unavailable or failed for:", placeName, error);
    return null;
  }
};
