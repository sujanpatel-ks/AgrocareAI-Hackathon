
/**
 * AgroCare AI Motion System
 * Centralized physics-aware transitions for "Grounded Realism".
 */
export const physics = {
  // Use for buttons and small interactive elements (Z-axis depression)
  // 'as const' ensures 'type' is inferred as the literal "spring" to satisfy Framer Motion types.
  bouncy: {
    type: "spring",
    stiffness: 400,
    damping: 20, // Specific damping for tactile feedback
    mass: 1
  } as const,
  // Use for cards and panels sliding into view
  smooth: {
    type: "spring",
    stiffness: 180,
    damping: 22,
    restDelta: 0.001
  } as const,
  // User's standard 'soft' spring for general transitions
  soft: {
    type: "spring",
    stiffness: 180,
    damping: 24,
  } as const,
  // User's standard 'firm' spring for crisp interactions
  firm: {
    type: "spring",
    stiffness: 260,
    damping: 20,
  } as const
};
