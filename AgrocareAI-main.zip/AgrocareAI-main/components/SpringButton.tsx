
import React from 'react';
import { motion } from 'framer-motion';
import { physics } from '../theme/motion';

interface SpringButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  className?: string;
  icon?: React.ReactNode;
  variant?: 'primary' | 'secondary';
  disabled?: boolean;
}

export const SpringButton: React.FC<SpringButtonProps> = ({ 
  onClick, 
  children, 
  icon,
  className = '', 
  variant = 'primary',
  disabled = false
}) => {
  const styles = {
    primary: "bg-[#2D6A4F] text-white",
    secondary: "bg-white text-[#2D6A4F] border border-gray-100",
  };

  return (
    <motion.button
      whileHover={{ y: -4, boxShadow: "0 12px 24px rgba(0,0,0,0.15)" }}
      whileTap={{ 
        scale: 0.98, // Physical depression into Z-axis
        y: 2,
        boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
      }}
      transition={physics.bouncy}
      onClick={onClick}
      disabled={disabled}
      className={`
        relative flex items-center justify-center gap-3 px-8 py-4 
        font-bold rounded-2xl shadow-soft disabled:opacity-50 disabled:grayscale
        ${styles[variant]} ${className}
      `}
    >
      {icon && <span className="opacity-90">{icon}</span>}
      {children}
    </motion.button>
  );
};
