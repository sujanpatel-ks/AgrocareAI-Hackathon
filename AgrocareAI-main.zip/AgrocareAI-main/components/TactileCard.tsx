
import React from 'react';
import { motion } from 'framer-motion';
import { physics } from '../theme/motion';

interface TactileCardProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
  delay?: number;
}

/**
 * DataCard (TactileCard): Implements the Material Illusion
 */
export const TactileCard: React.FC<TactileCardProps> = ({ 
  children, 
  title, 
  className = '', 
  delay = 0 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      whileHover={{ y: -4 }}
      transition={{ ...physics.soft, delay }}
      className={`
        material-matte shadow-tactile rounded-[32px] p-6 
        ${className}
      `}
    >
      {title && <h3 className="text-lg font-bold text-gray-900 mb-4">{title}</h3>}
      {children}
    </motion.div>
  );
};

/**
 * GlassPanel (GlassOverlay): Glassmorphism 2.0 implementation
 */
export const GlassOverlay: React.FC<{ children: React.ReactNode; className?: string }> = ({ 
  children, 
  className = '' 
}) => (
  <div className={`glass-2 rounded-[24px] p-5 shadow-soft ${className}`}>
    {children}
  </div>
);
