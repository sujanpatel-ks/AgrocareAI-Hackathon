
import React, { useEffect, useRef } from 'react';
import { StoreLocation } from '../types';

interface SupplierMapProps {
  suppliers: StoreLocation[];
  userLocation: { lat: number; lng: number } | null;
  selectedStoreTitle?: string | null;
  onStoreSelect?: (title: string) => void;
}

declare const L: any;

export const SupplierMap: React.FC<SupplierMapProps> = ({ 
  suppliers, 
  userLocation, 
  selectedStoreTitle, 
  onStoreSelect 
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersLayerRef = useRef<any>(null);

  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const center = userLocation ? [userLocation.lat, userLocation.lng] : [20.5937, 78.9629];
    mapInstanceRef.current = L.map(mapContainerRef.current, {
      zoomControl: false, 
      scrollWheelZoom: false,
    }).setView(center, 13);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; CARTO'
    }).addTo(mapInstanceRef.current);

    markersLayerRef.current = L.layerGroup().addTo(mapInstanceRef.current);

    L.control.zoom({ position: 'topright' }).addTo(mapInstanceRef.current);

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!mapInstanceRef.current || !markersLayerRef.current) return;

    markersLayerRef.current.clearLayers();
    const bounds = L.latLngBounds();
    let hasValidPoints = false;

    // User Location Marker
    if (userLocation) {
      const userLatLng = [userLocation.lat, userLocation.lng];
      L.circleMarker(userLatLng, {
        radius: 10,
        fillColor: "#3B82F6",
        color: "white",
        weight: 3,
        opacity: 1,
        fillOpacity: 0.8
      }).addTo(markersLayerRef.current).bindPopup("<b>You are here</b>");
      bounds.extend(userLatLng);
      hasValidPoints = true;
    }

    // Supplier Markers
    suppliers.forEach(store => {
      if (store.lat && store.lng) {
        const latLng = [store.lat, store.lng];
        const isSelected = selectedStoreTitle === store.title;
        const markerColor = store.isEstimated ? '#F59E0B' : '#2D6A4F';
        
        const markerIcon = L.divIcon({
          className: 'custom-marker',
          html: `<div class="${isSelected ? 'active-marker-pulse' : ''}" style="background-color: ${markerColor}; width: 18px; height: 18px; border: 3px solid white; border-radius: 50%; box-shadow: 0 4px 12px rgba(0,0,0,0.25); position: relative;">
                  ${store.isEstimated ? '<div style="position: absolute; top: -10px; right: -10px; font-size: 8px; background: white; padding: 2px 4px; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); border: 1px solid #F59E0B; color: #F59E0B; font-weight: 900;">EST</div>' : ''}
                 </div>`,
          iconSize: [18, 18],
          iconAnchor: [9, 9]
        });

        const storeMarker = L.marker(latLng, { icon: markerIcon }).addTo(markersLayerRef.current);

        storeMarker.on('click', () => {
          if (onStoreSelect) onStoreSelect(store.title);
        });

        storeMarker.bindPopup(`
          <div style="font-family: Inter, sans-serif; padding: 8px; min-width: 180px;">
            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
              <b style="font-size: 14px; color: #111827;">${store.title}</b>
              ${store.isVerified ? '<span style="color: #2D6A4F; font-size: 12px;">✓</span>' : ''}
            </div>
            <div style="font-size: 10px; color: ${markerColor}; font-weight: 800; text-transform: uppercase; margin-bottom: 8px;">
              ${store.isEstimated ? 'Approximate Location' : 'Precise Coordinates'}
            </div>
            <div style="font-size: 11px; color: #6B7280; font-weight: 600; margin-bottom: 4px;">
              ${store.distance?.toFixed(2)} KM AWAY
            </div>
            ${store.isEstimated ? '<div style="font-size: 9px; color: #92400E; background: #FEF3C7; padding: 4px 8px; border-radius: 4px; border: 1px solid #FDE68A; line-height: 1.2;"><b>Note:</b> Coordinates are estimated as precise geocoding was unavailable.</div>' : ''}
            <div style="margin-top: 10px; font-size: 10px; color: #2D6A4F; font-weight: 900; text-transform: uppercase; letter-spacing: 0.1em;">Click to view details</div>
          </div>
        `, { className: 'tactile-popup' });
        
        bounds.extend(latLng);
        hasValidPoints = true;
      }
    });

    if (hasValidPoints && !selectedStoreTitle) {
      mapInstanceRef.current.fitBounds(bounds, { padding: [60, 60], maxZoom: 15 });
    }
  }, [suppliers, userLocation, selectedStoreTitle]);

  return (
    <div className="relative w-full h-full rounded-[32px] overflow-hidden border border-gray-100 shadow-inner group">
      <div ref={mapContainerRef} className="w-full h-full" />
      <div className="absolute top-4 left-4 z-[1000] flex flex-col gap-2">
        <div className="bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/50 shadow-soft text-[9px] font-black text-gray-500 flex items-center gap-2 transition-transform group-hover:scale-105">
          <div className="w-2 h-2 rounded-full bg-blue-500" /> ACTIVE GPS SIGNAL
        </div>
      </div>
    </div>
  );
};
