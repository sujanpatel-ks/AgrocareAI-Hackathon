
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { physics } from '../theme/motion';

interface VisionScannerProps {
  onCapture: (base64: string) => void;
  onClose: () => void;
}

export const VisionScanner: React.FC<VisionScannerProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [hasStream, setHasStream] = useState(false);
  const [permissionError, setPermissionError] = useState<string | null>(null);
  
  // Intelligence states
  const [luminosity, setLuminosity] = useState(100);
  const [isSteady, setIsSteady] = useState(true);
  const [centeringStatus, setCenteringStatus] = useState<'searching' | 'aligned'>('searching');

  const startCamera = useCallback(async () => {
    setPermissionError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment', 
          width: { ideal: 1920 }, 
          height: { ideal: 1080 } 
        },
        audio: false 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setHasStream(true);
      }
    } catch (err: any) {
      setPermissionError("Camera access required for real-time pathology detection.");
    }
  }, []);

  // Monitor luminosity and jitter
  useEffect(() => {
    let frameId: number;
    const checkQuality = () => {
      if (videoRef.current && hasStream) {
        const canvas = document.createElement('canvas');
        canvas.width = 100;
        canvas.height = 100;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(videoRef.current, 0, 0, 100, 100);
          const data = ctx.getImageData(0, 0, 100, 100).data;
          let sum = 0;
          for (let i = 0; i < data.length; i += 4) {
            sum += (data[i] + data[i+1] + data[i+2]) / 3;
          }
          setLuminosity(sum / 2500); // Normalized 0-100 approx
        }
      }
      frameId = requestAnimationFrame(checkQuality);
    };

    const handleMotion = (event: DeviceMotionEvent) => {
      const acc = event.accelerationIncludingGravity;
      if (acc) {
        const total = Math.abs(acc.x || 0) + Math.abs(acc.y || 0) + Math.abs(acc.z || 0);
        // Basic jitter detection
        setIsSteady(total < 15); // Calibration for steady hold
      }
    };

    checkQuality();
    window.addEventListener('devicemotion', handleMotion);
    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('devicemotion', handleMotion);
    };
  }, [hasStream]);

  useEffect(() => {
    startCamera();
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [startCamera]);

  const handleCapture = () => {
    if (!videoRef.current || !canvasRef.current || isScanning || !hasStream) return;
    setIsScanning(true);
    
    setTimeout(() => {
      const video = videoRef.current!;
      const canvas = canvasRef.current!;
      const size = 1024; 
      canvas.width = size;
      canvas.height = size;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const sourceWidth = video.videoWidth;
        const sourceHeight = video.videoHeight;
        const minDim = Math.min(sourceWidth, sourceHeight);
        const sx = (sourceWidth - minDim) / 2;
        const sy = (sourceHeight - minDim) / 2;
        
        ctx.drawImage(video, sx, sy, minDim, minDim, 0, 0, size, size);
        const base64 = canvas.toDataURL('image/jpeg', 0.8);
        onCapture(base64);
      }
      setIsScanning(false);
    }, 500);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center overflow-hidden"
    >
      {permissionError ? (
        <div className="z-[110] px-8 text-center max-w-sm">
          <div className="w-20 h-20 bg-red-500/10 rounded-[28px] flex items-center justify-center text-red-500 mx-auto mb-6 border border-red-500/20">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path></svg>
          </div>
          <h2 className="text-xl font-black text-white tracking-tight mb-3">Sensor Blocked</h2>
          <button onClick={onClose} className="bg-white text-black font-black py-4 px-8 rounded-2xl w-full">Go Back</button>
        </div>
      ) : (
        <>
          <video ref={videoRef} autoPlay playsInline muted className="absolute inset-0 w-full h-full object-cover opacity-80" />
          <canvas ref={canvasRef} className="hidden" />

          {/* Smart Alignment Guides */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <motion.div 
              animate={{ 
                scale: centeringStatus === 'aligned' ? 1 : [0.95, 1, 0.95],
                borderColor: luminosity < 40 ? 'rgba(239, 68, 68, 0.5)' : '#2D6A4F'
              }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-[280px] h-[360px] border-2 border-dashed rounded-[60px] relative flex items-center justify-center"
            >
              <svg width="200" height="280" viewBox="0 0 100 140" fill="none" className="opacity-30">
                <path d="M50 10C50 10 10 50 10 90C10 120 50 130 50 130C50 130 90 120 90 90C90 50 50 10 50 10Z" stroke="white" strokeWidth="2" strokeDasharray="4 4" />
              </svg>
              
              {/* Corner Brackets */}
              <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-white/40 rounded-tl-2xl" />
              <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-white/40 rounded-tr-2xl" />
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-white/40 rounded-bl-2xl" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-white/40 rounded-br-2xl" />
            </motion.div>
          </div>

          <div className="absolute top-10 left-8 right-8 flex justify-between items-start">
            <button onClick={onClose} className="w-12 h-12 bg-white/10 backdrop-blur-xl rounded-2xl flex items-center justify-center text-white border border-white/20">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            
            <div className="flex flex-col gap-2 items-end">
              <div className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 border ${luminosity < 40 ? 'bg-red-500/20 text-red-500 border-red-500/30' : 'bg-black/40 text-white border-white/10'}`}>
                <div className={`w-2 h-2 rounded-full ${luminosity < 40 ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`} />
                {luminosity < 40 ? 'Low Light' : 'Optimal Lux'}
              </div>
              <div className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 border ${!isSteady ? 'bg-orange-500/20 text-orange-500 border-orange-500/30' : 'bg-black/40 text-white border-white/10'}`}>
                <div className={`w-2 h-2 rounded-full ${!isSteady ? 'bg-orange-500 animate-pulse' : 'bg-blue-500'}`} />
                {!isSteady ? 'Holding Shaky' : 'Instrument Steady'}
              </div>
            </div>
          </div>

          <div className="absolute bottom-16 w-full flex flex-col items-center gap-8">
            <div className="flex flex-col items-center gap-2">
              <p className="text-white text-[10px] font-black uppercase tracking-[0.4em] opacity-60">Calibrate Subject</p>
              <div className="h-0.5 w-12 bg-[#2D6A4F] rounded-full" />
            </div>

            <motion.button
              whileTap={{ scale: 0.85 }}
              onClick={handleCapture}
              disabled={isScanning || !hasStream || !isSteady}
              className={`w-24 h-24 rounded-full border-[10px] flex items-center justify-center shadow-2xl transition-all ${!isSteady ? 'border-gray-500/30 opacity-50' : 'border-white/30 active:border-[#2D6A4F]'}`}
            >
              <div className={`w-14 h-14 rounded-full transition-all ${isScanning ? 'bg-red-500 scale-75' : 'bg-white'}`} />
            </motion.button>
          </div>
        </>
      )}
    </motion.div>
  );
};
